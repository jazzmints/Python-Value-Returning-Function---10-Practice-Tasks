
def add_numbers(num1, num2):    #exercise 2
   answer = int(num1) + int(num2)
   print(answer)
   return answer



num1 = input('Please enter a number')
num2 = input('Please enter a number')
add_numbers(num1, num2)

#exercise 3
def adding(list_of_numbers):
    count = 0
    for i in list_of_numbers:
              count+=i 

    print(count)
    return count       





nums = [3,6,9]


adding(nums)


#Task 2

def multiply_numbers(a, b):
    return a * b

result = multiply_numbers(8, 6)
print(result)

multiply_numbers(8, 6)


#Exercise 1
def multiply_nums(c, b):
     return c * b
result = multiply_nums(12,7)
print(result)

multiply_nums(12,7)

#Exercise 2
def find_area(w,h):
     return area

h = input ('Please enter Width:')
w = input ('Please enter Height:')
area = int(w)*int(h)

print(area)
find_area(w,h)


def find_volume(w,h,l):
     return volume

h = input ('Please enter Width:')
w = input ('Please enter Height:')
l = input ('Please enter length')
volume= int(w)*int(h)*int(l)

print(volume)
find_volume(w,h,l)


#Task 3

def find_rec():
    return True
true = 9 * 6
sum = true
print(sum)

find_rec()

def rec_find():
     h1 = input('Please enter Width:')
     w1 = input('Please enter Height:')
     area1 = int(h1) * int(w1)
     print('The rectangle area is', area1, 'square units')
     return area1

rec_find()
     


def weekly_pay(hrs,rate):
   hrs = 40
   rate = 22
   pay = hrs * rate
   print(pay)
   return pay



weekly_pay(40,22)


def employee_rate():
   name = input('What is the employee name?:')
   hour = float(input('How many hours worked?:'))
   work = float(input('How much per hour?:'))
   week_pay = hour * work
   print('Employee:', name)
   print('Weekly pay is $', week_pay)

employee_rate()

# exercise 3

def weekly_pay_ex3():
    emp_a_hrs = float(input('Employee A hours:'))
    emp_a_rate = float(input('Employee A rate:'))
    pay_a = emp_a_hrs * emp_a_rate

    emp_b_hrs = float(input('Employee B hours:'))
    emp_b_rate = float(input('Employee B rate:'))
    pay_b = emp_b_hrs * emp_b_rate

    emp_c_hrs = float(input('Employee C hours:'))
    emp_c_rate = float(input('Employee C rate:'))
    pay_c = emp_c_hrs * emp_c_rate

    grand_payroll = pay_a + pay_b + pay_c

    print('Employee A $', pay_a)
    print('Employee B $', pay_b)
    print('Employee C $', pay_c)
    print('Grand Payroll = $', grand_payroll)



# Task 5
def task5_ex1():
    return (80 + 90 + 100) / 3

def task5_ex2():
    s1 = float(input('Score 1:'))
    s2 = float(input('Score 2:'))
    s3 = float(input('Score 3:'))
    s4 = float(input('Score 4:'))
    s5 = float(input('Score 5:'))
    average = (s1 + s2 + s3 + s4 + s5) / 5
    return average

def task5_ex3():
    avg = float(input('Enter average score:'))
    print('Average =', avg)
    
    if avg >= 90:
        print('Grade = A')
    elif avg >= 80:
        print('Grade = B')
    elif avg >= 70:
        print('Grade = C')
    elif avg >= 60:
        print('Grade = D')
    else:
        print('Grade = F')



# Task: Convert Hours to Minutes


def hours_to_min_ex1():
    return 5 * 60

def hours_to_min_ex2():
    hours = float(input('Enter hours:'))
    minutes = hours * 60
    print('Hours:', hours)
    print('Minutes:', minutes)

def hours_to_min_ex3():
    hours = float(input('Enter hours:'))
    minutes = hours * 60
    seconds = minutes * 60
    print('Hours =', hours)
    print('Minutes =', minutes)
    print('Seconds =', seconds)
    return minutes, seconds


# Task 7


def task7_ex1():
    return (30 * 9 / 5) + 32

def task7_ex2():
    celsius = float(input('Enter Celsius temperature:'))
    fahrenheit = (celsius * 9 / 5) + 32
    print('Celsius:', celsius)
    print('Fahrenheit:', fahrenheit)

def task7_ex3():
    celsius = float(input('Enter Celsius temperature:'))
    fahrenheit = (celsius * 9 / 5) + 32
    print(celsius, 'C')
    print(fahrenheit, 'F')
    
    if celsius <= 0:
        print('Weather: Freezing')
    elif celsius <= 15:
        print('Weather: Cold')
    elif celsius <= 25:
        print('Weather: Warm')
    else:
        print('Weather: Hot')

# Task 8

def task8_ex1():
    price = 200
    discount = 35
    return price - discount

def task8_ex2():
    product = input('Product Name:')
    price = float(input('Original Price:'))
    discount = float(input('Discount:'))
    final_price = price - discount
    
    print('Product:', product)
    print('Original Price: $', price)
    print('Discount: $', discount)
    print('Final Price: $', final_price)

def task8_ex3():
    p1 = float(input('Product 1 price:'))
    d1 = float(input('Product 1 discount:'))
    p2 = float(input('Product 2 price:'))
    d2 = float(input('Product 2 discount:'))
    p3 = float(input('Product 3 price:'))
    d3 = float(input('Product 3 discount:'))
    p4 = float(input('Product 4 price:'))
    d4 = float(input('Product 4 discount:'))
    
    subtotal = p1 + p2 + p3 + p4
    total_discount = d1 + d2 + d3 + d4
    final_total = subtotal - total_discount
    
    print('Subtotal: $', subtotal)
    print('Total Discount: $', total_discount)
    print('Final Total: $', final_total)



# Task 9

def task9_ex1():
    principal = 4000
    rate = 5
    time = 4
    return (principal * rate * time) / 100

def task9_ex2():
    principal = float(input('Principal:'))
    rate = float(input('Rate:'))
    time = float(input('Time:'))
    interest = (principal * rate * time) / 100
    return interest

def task9_ex3():
    principal = float(input('Principal:'))
    rate = float(input('Rate:'))
    time = float(input('Time:'))
    
    interest = (principal * rate * time) / 100
    final_amount = principal + interest
    
    print('Interest: $', interest)
    print('Final Amount: $', final_amount)
    return interest, final_amount



# Task 10


def task10_ex1():
    liabilities = 40000
    equity = 60000
    return liabilities + equity

def task10_ex2():
    company = input('Company Name:')
    liabilities = float(input('Liabilities:'))
    equity = float(input('Equity:'))
    assets = liabilities + equity
    
    print('Company:', company)
    print('Assets: $', assets)
    print('Liabilities: $', liabilities)
    print('Equity: $', equity)
    return assets

def task10_ex3():
    comp_a_liab = float(input('Company A Liabilities:'))
    comp_a_eq = float(input('Company A Equity:'))
    assets_a = comp_a_liab + comp_a_eq
    
    comp_b_liab = float(input('Company B Liabilities:'))
    comp_b_eq = float(input('Company B Equity:'))
    assets_b = comp_b_liab + comp_b_eq
    
    comp_c_liab = float(input('Company C Liabilities:'))
    comp_c_eq = float(input('Company C Equity:'))
    assets_c = comp_c_liab + comp_c_eq
    
    combined = assets_a + assets_b + assets_c
    
    print('Company A')
    print('Assets: $', assets_a)
    print('Company B')
    print('Assets: $', assets_b)
    print('Company C')
    print('Assets: $', assets_c)
    print('Combined Assets: $', combined)
